# M1_CHPS_OBHPC_INFO_TD2

TD2 Version provisoire
Programmation C et mesures de performances
Principaux compléments en cours de travail :
    • Compilateurs ICC et ICX
    • Améliorations graphiques
    • Analyse complémentaire

Objet :
	Il s'agit de réaliser un benchmark de la bande passante mémoire (et par extension de la latence mémoire).
	Pour ce faire, nous répétons un relativement grand nombre de fois des opérations choisies dont on connait le nombre de cycles.
	Nous faisons varier les paramètres indiqués ci-dessous.
